var require = meteorInstall({"imports":{"api":{"lists":{"server":{"publications.js":["meteor/meteor","../lists.js",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/lists/server/publications.js                                                                            //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var Meteor = void 0;                                                                                                   // 1
module.importSync("meteor/meteor", {                                                                                   // 1
  "Meteor": function (v) {                                                                                             // 1
    Meteor = v;                                                                                                        // 1
  }                                                                                                                    // 1
}, 0);                                                                                                                 // 1
var Lists = void 0;                                                                                                    // 1
module.importSync("../lists.js", {                                                                                     // 1
  "Lists": function (v) {                                                                                              // 1
    Lists = v;                                                                                                         // 1
  }                                                                                                                    // 1
}, 1);                                                                                                                 // 1
Meteor.publish('lists.public', function () {                                                                           // 7
  function listsPublic() {                                                                                             // 7
    return Lists.find({                                                                                                // 8
      userId: {                                                                                                        // 9
        $exists: false                                                                                                 // 9
      }                                                                                                                // 9
    }, {                                                                                                               // 8
      fields: Lists.publicFields                                                                                       // 11
    });                                                                                                                // 10
  }                                                                                                                    // 13
                                                                                                                       //
  return listsPublic;                                                                                                  // 7
}());                                                                                                                  // 7
Meteor.publish('lists.private', function () {                                                                          // 15
  function listsPrivate() {                                                                                            // 15
    if (!this.userId) {                                                                                                // 16
      return this.ready();                                                                                             // 17
    }                                                                                                                  // 18
                                                                                                                       //
    return Lists.find({                                                                                                // 20
      userId: this.userId                                                                                              // 21
    }, {                                                                                                               // 20
      fields: Lists.publicFields                                                                                       // 23
    });                                                                                                                // 22
  }                                                                                                                    // 25
                                                                                                                       //
  return listsPrivate;                                                                                                 // 15
}());                                                                                                                  // 15
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"lists.js":["babel-runtime/helpers/classCallCheck","babel-runtime/helpers/possibleConstructorReturn","babel-runtime/helpers/inherits","meteor/mongo","meteor/aldeed:simple-schema","meteor/dburles:factory","meteor/tap:i18n","../todos/todos.js",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/lists/lists.js                                                                                          //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var _classCallCheck2 = require("babel-runtime/helpers/classCallCheck");                                                //
                                                                                                                       //
var _classCallCheck3 = _interopRequireDefault(_classCallCheck2);                                                       //
                                                                                                                       //
var _possibleConstructorReturn2 = require("babel-runtime/helpers/possibleConstructorReturn");                          //
                                                                                                                       //
var _possibleConstructorReturn3 = _interopRequireDefault(_possibleConstructorReturn2);                                 //
                                                                                                                       //
var _inherits2 = require("babel-runtime/helpers/inherits");                                                            //
                                                                                                                       //
var _inherits3 = _interopRequireDefault(_inherits2);                                                                   //
                                                                                                                       //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }                      //
                                                                                                                       //
module.export({                                                                                                        // 1
  Lists: function () {                                                                                                 // 1
    return Lists;                                                                                                      // 1
  }                                                                                                                    // 1
});                                                                                                                    // 1
var Mongo = void 0;                                                                                                    // 1
module.importSync("meteor/mongo", {                                                                                    // 1
  "Mongo": function (v) {                                                                                              // 1
    Mongo = v;                                                                                                         // 1
  }                                                                                                                    // 1
}, 0);                                                                                                                 // 1
var SimpleSchema = void 0;                                                                                             // 1
module.importSync("meteor/aldeed:simple-schema", {                                                                     // 1
  "SimpleSchema": function (v) {                                                                                       // 1
    SimpleSchema = v;                                                                                                  // 1
  }                                                                                                                    // 1
}, 1);                                                                                                                 // 1
var Factory = void 0;                                                                                                  // 1
module.importSync("meteor/dburles:factory", {                                                                          // 1
  "Factory": function (v) {                                                                                            // 1
    Factory = v;                                                                                                       // 1
  }                                                                                                                    // 1
}, 2);                                                                                                                 // 1
var TAPi18n = void 0;                                                                                                  // 1
module.importSync("meteor/tap:i18n", {                                                                                 // 1
  "TAPi18n": function (v) {                                                                                            // 1
    TAPi18n = v;                                                                                                       // 1
  }                                                                                                                    // 1
}, 3);                                                                                                                 // 1
var Todos = void 0;                                                                                                    // 1
module.importSync("../todos/todos.js", {                                                                               // 1
  "Todos": function (v) {                                                                                              // 1
    Todos = v;                                                                                                         // 1
  }                                                                                                                    // 1
}, 4);                                                                                                                 // 1
                                                                                                                       //
var ListsCollection = function (_Mongo$Collection) {                                                                   //
  (0, _inherits3.default)(ListsCollection, _Mongo$Collection);                                                         //
                                                                                                                       //
  function ListsCollection() {                                                                                         //
    (0, _classCallCheck3.default)(this, ListsCollection);                                                              //
    return (0, _possibleConstructorReturn3.default)(this, _Mongo$Collection.apply(this, arguments));                   //
  }                                                                                                                    //
                                                                                                                       //
  ListsCollection.prototype.insert = function () {                                                                     //
    function insert(list, callback) {                                                                                  //
      var language = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : 'en';                         // 9
      var ourList = list;                                                                                              // 10
                                                                                                                       //
      if (!ourList.name) {                                                                                             // 11
        var defaultName = TAPi18n.__('lists.insert.list', null, language);                                             // 12
                                                                                                                       //
        var nextLetter = 'A';                                                                                          // 13
        ourList.name = defaultName + " " + nextLetter;                                                                 // 14
                                                                                                                       //
        while (this.findOne({                                                                                          // 16
          name: ourList.name                                                                                           // 16
        })) {                                                                                                          // 16
          // not going to be too smart here, can go past Z                                                             // 17
          nextLetter = String.fromCharCode(nextLetter.charCodeAt(0) + 1);                                              // 18
          ourList.name = defaultName + " " + nextLetter;                                                               // 19
        }                                                                                                              // 20
      }                                                                                                                // 21
                                                                                                                       //
      return _Mongo$Collection.prototype.insert.call(this, ourList, callback);                                         // 23
    }                                                                                                                  // 24
                                                                                                                       //
    return insert;                                                                                                     //
  }();                                                                                                                 //
                                                                                                                       //
  ListsCollection.prototype.remove = function () {                                                                     //
    function remove(selector, callback) {                                                                              //
      Todos.remove({                                                                                                   // 26
        listId: selector                                                                                               // 26
      });                                                                                                              // 26
      return _Mongo$Collection.prototype.remove.call(this, selector, callback);                                        // 27
    }                                                                                                                  // 28
                                                                                                                       //
    return remove;                                                                                                     //
  }();                                                                                                                 //
                                                                                                                       //
  return ListsCollection;                                                                                              //
}(Mongo.Collection);                                                                                                   //
                                                                                                                       //
var Lists = new ListsCollection('lists');                                                                              // 31
// Deny all client-side updates since we will be using methods to manage this collection                               // 33
Lists.deny({                                                                                                           // 34
  insert: function () {                                                                                                // 35
    return true;                                                                                                       // 35
  },                                                                                                                   // 35
  update: function () {                                                                                                // 36
    return true;                                                                                                       // 36
  },                                                                                                                   // 36
  remove: function () {                                                                                                // 37
    return true;                                                                                                       // 37
  }                                                                                                                    // 37
});                                                                                                                    // 34
Lists.schema = new SimpleSchema({                                                                                      // 40
  _id: {                                                                                                               // 41
    type: String,                                                                                                      // 41
    regEx: SimpleSchema.RegEx.Id                                                                                       // 41
  },                                                                                                                   // 41
  name: {                                                                                                              // 42
    type: String                                                                                                       // 42
  },                                                                                                                   // 42
  incompleteCount: {                                                                                                   // 43
    type: Number,                                                                                                      // 43
    defaultValue: 0                                                                                                    // 43
  },                                                                                                                   // 43
  userId: {                                                                                                            // 44
    type: String,                                                                                                      // 44
    regEx: SimpleSchema.RegEx.Id,                                                                                      // 44
    optional: true                                                                                                     // 44
  }                                                                                                                    // 44
});                                                                                                                    // 40
Lists.attachSchema(Lists.schema); // This represents the keys from Lists objects that should be published              // 47
// to the client. If we add secret properties to List objects, don't list                                              // 50
// them here to keep them private to the server.                                                                       // 51
                                                                                                                       //
Lists.publicFields = {                                                                                                 // 52
  name: 1,                                                                                                             // 53
  incompleteCount: 1,                                                                                                  // 54
  userId: 1                                                                                                            // 55
};                                                                                                                     // 52
Factory.define('list', Lists, {});                                                                                     // 58
Lists.helpers({                                                                                                        // 60
  // A list is considered to be private if it has a userId set                                                         // 61
  isPrivate: function () {                                                                                             // 62
    return !!this.userId;                                                                                              // 63
  },                                                                                                                   // 64
  isLastPublicList: function () {                                                                                      // 65
    var publicListCount = Lists.find({                                                                                 // 66
      userId: {                                                                                                        // 66
        $exists: false                                                                                                 // 66
      }                                                                                                                // 66
    }).count();                                                                                                        // 66
    return !this.isPrivate() && publicListCount === 1;                                                                 // 67
  },                                                                                                                   // 68
  editableBy: function (userId) {                                                                                      // 69
    if (!this.userId) {                                                                                                // 70
      return true;                                                                                                     // 71
    }                                                                                                                  // 72
                                                                                                                       //
    return this.userId === userId;                                                                                     // 74
  },                                                                                                                   // 75
  todos: function () {                                                                                                 // 76
    return Todos.find({                                                                                                // 77
      listId: this._id                                                                                                 // 77
    }, {                                                                                                               // 77
      sort: {                                                                                                          // 77
        createdAt: -1                                                                                                  // 77
      }                                                                                                                // 77
    });                                                                                                                // 77
  }                                                                                                                    // 78
});                                                                                                                    // 60
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"methods.js":["meteor/meteor","meteor/mdg:validated-method","meteor/aldeed:simple-schema","meteor/ddp-rate-limiter","meteor/underscore","./lists.js",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/lists/methods.js                                                                                        //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({                                                                                                        // 1
  insert: function () {                                                                                                // 1
    return insert;                                                                                                     // 1
  },                                                                                                                   // 1
  makePrivate: function () {                                                                                           // 1
    return makePrivate;                                                                                                // 1
  },                                                                                                                   // 1
  makePublic: function () {                                                                                            // 1
    return makePublic;                                                                                                 // 1
  },                                                                                                                   // 1
  updateName: function () {                                                                                            // 1
    return updateName;                                                                                                 // 1
  },                                                                                                                   // 1
  remove: function () {                                                                                                // 1
    return remove;                                                                                                     // 1
  }                                                                                                                    // 1
});                                                                                                                    // 1
var Meteor = void 0;                                                                                                   // 1
module.importSync("meteor/meteor", {                                                                                   // 1
  "Meteor": function (v) {                                                                                             // 1
    Meteor = v;                                                                                                        // 1
  }                                                                                                                    // 1
}, 0);                                                                                                                 // 1
var ValidatedMethod = void 0;                                                                                          // 1
module.importSync("meteor/mdg:validated-method", {                                                                     // 1
  "ValidatedMethod": function (v) {                                                                                    // 1
    ValidatedMethod = v;                                                                                               // 1
  }                                                                                                                    // 1
}, 1);                                                                                                                 // 1
var SimpleSchema = void 0;                                                                                             // 1
module.importSync("meteor/aldeed:simple-schema", {                                                                     // 1
  "SimpleSchema": function (v) {                                                                                       // 1
    SimpleSchema = v;                                                                                                  // 1
  }                                                                                                                    // 1
}, 2);                                                                                                                 // 1
var DDPRateLimiter = void 0;                                                                                           // 1
module.importSync("meteor/ddp-rate-limiter", {                                                                         // 1
  "DDPRateLimiter": function (v) {                                                                                     // 1
    DDPRateLimiter = v;                                                                                                // 1
  }                                                                                                                    // 1
}, 3);                                                                                                                 // 1
                                                                                                                       //
var _ = void 0;                                                                                                        // 1
                                                                                                                       //
module.importSync("meteor/underscore", {                                                                               // 1
  "_": function (v) {                                                                                                  // 1
    _ = v;                                                                                                             // 1
  }                                                                                                                    // 1
}, 4);                                                                                                                 // 1
var Lists = void 0;                                                                                                    // 1
module.importSync("./lists.js", {                                                                                      // 1
  "Lists": function (v) {                                                                                              // 1
    Lists = v;                                                                                                         // 1
  }                                                                                                                    // 1
}, 5);                                                                                                                 // 1
var LIST_ID_ONLY = new SimpleSchema({                                                                                  // 9
  listId: Lists.simpleSchema().schema('_id')                                                                           // 10
}).validator({                                                                                                         // 9
  clean: true,                                                                                                         // 11
  filter: false                                                                                                        // 11
});                                                                                                                    // 11
var insert = new ValidatedMethod({                                                                                     // 13
  name: 'lists.insert',                                                                                                // 14
  validate: new SimpleSchema({                                                                                         // 15
    language: {                                                                                                        // 16
      type: String                                                                                                     // 17
    }                                                                                                                  // 16
  }).validator(),                                                                                                      // 15
  run: function (_ref) {                                                                                               // 20
    var language = _ref.language;                                                                                      // 20
    return Lists.insert({}, null, language);                                                                           // 21
  }                                                                                                                    // 22
});                                                                                                                    // 13
var makePrivate = new ValidatedMethod({                                                                                // 25
  name: 'lists.makePrivate',                                                                                           // 26
  validate: LIST_ID_ONLY,                                                                                              // 27
  run: function (_ref2) {                                                                                              // 28
    var listId = _ref2.listId;                                                                                         // 28
                                                                                                                       //
    if (!this.userId) {                                                                                                // 29
      throw new Meteor.Error('lists.makePrivate.notLoggedIn', 'Must be logged in to make private lists.');             // 30
    }                                                                                                                  // 32
                                                                                                                       //
    var list = Lists.findOne(listId);                                                                                  // 34
                                                                                                                       //
    if (list.isLastPublicList()) {                                                                                     // 36
      throw new Meteor.Error('lists.makePrivate.lastPublicList', 'Cannot make the last public list private.');         // 37
    }                                                                                                                  // 39
                                                                                                                       //
    Lists.update(listId, {                                                                                             // 41
      $set: {                                                                                                          // 42
        userId: this.userId                                                                                            // 42
      }                                                                                                                // 42
    });                                                                                                                // 41
  }                                                                                                                    // 44
});                                                                                                                    // 25
var makePublic = new ValidatedMethod({                                                                                 // 47
  name: 'lists.makePublic',                                                                                            // 48
  validate: LIST_ID_ONLY,                                                                                              // 49
  run: function (_ref3) {                                                                                              // 50
    var listId = _ref3.listId;                                                                                         // 50
                                                                                                                       //
    if (!this.userId) {                                                                                                // 51
      throw new Meteor.Error('lists.makePublic.notLoggedIn', 'Must be logged in.');                                    // 52
    }                                                                                                                  // 54
                                                                                                                       //
    var list = Lists.findOne(listId);                                                                                  // 56
                                                                                                                       //
    if (!list.editableBy(this.userId)) {                                                                               // 58
      throw new Meteor.Error('lists.makePublic.accessDenied', 'You don\'t have permission to edit this list.');        // 59
    } // XXX the security check above is not atomic, so in theory a race condition could                               // 61
    // result in exposing private data                                                                                 // 64
                                                                                                                       //
                                                                                                                       //
    Lists.update(listId, {                                                                                             // 65
      $unset: {                                                                                                        // 66
        userId: true                                                                                                   // 66
      }                                                                                                                // 66
    });                                                                                                                // 65
  }                                                                                                                    // 68
});                                                                                                                    // 47
var updateName = new ValidatedMethod({                                                                                 // 71
  name: 'lists.updateName',                                                                                            // 72
  validate: new SimpleSchema({                                                                                         // 73
    listId: Lists.simpleSchema().schema('_id'),                                                                        // 74
    newName: Lists.simpleSchema().schema('name')                                                                       // 75
  }).validator({                                                                                                       // 73
    clean: true,                                                                                                       // 76
    filter: false                                                                                                      // 76
  }),                                                                                                                  // 76
  run: function (_ref4) {                                                                                              // 77
    var listId = _ref4.listId,                                                                                         // 77
        newName = _ref4.newName;                                                                                       // 77
    var list = Lists.findOne(listId);                                                                                  // 78
                                                                                                                       //
    if (!list.editableBy(this.userId)) {                                                                               // 80
      throw new Meteor.Error('lists.updateName.accessDenied', 'You don\'t have permission to edit this list.');        // 81
    } // XXX the security check above is not atomic, so in theory a race condition could                               // 83
    // result in exposing private data                                                                                 // 86
                                                                                                                       //
                                                                                                                       //
    Lists.update(listId, {                                                                                             // 88
      $set: {                                                                                                          // 89
        name: newName                                                                                                  // 89
      }                                                                                                                // 89
    });                                                                                                                // 88
  }                                                                                                                    // 91
});                                                                                                                    // 71
var remove = new ValidatedMethod({                                                                                     // 94
  name: 'lists.remove',                                                                                                // 95
  validate: LIST_ID_ONLY,                                                                                              // 96
  run: function (_ref5) {                                                                                              // 97
    var listId = _ref5.listId;                                                                                         // 97
    var list = Lists.findOne(listId);                                                                                  // 98
                                                                                                                       //
    if (!list.editableBy(this.userId)) {                                                                               // 100
      throw new Meteor.Error('lists.remove.accessDenied', 'You don\'t have permission to remove this list.');          // 101
    } // XXX the security check above is not atomic, so in theory a race condition could                               // 103
    // result in exposing private data                                                                                 // 106
                                                                                                                       //
                                                                                                                       //
    if (list.isLastPublicList()) {                                                                                     // 108
      throw new Meteor.Error('lists.remove.lastPublicList', 'Cannot delete the last public list.');                    // 109
    }                                                                                                                  // 111
                                                                                                                       //
    Lists.remove(listId);                                                                                              // 113
  }                                                                                                                    // 114
});                                                                                                                    // 94
                                                                                                                       //
// Get list of all method names on Lists                                                                               // 117
var LISTS_METHODS = _.pluck([insert, makePublic, makePrivate, updateName, remove], 'name');                            // 118
                                                                                                                       //
if (Meteor.isServer) {                                                                                                 // 126
  // Only allow 5 list operations per connection per second                                                            // 127
  DDPRateLimiter.addRule({                                                                                             // 128
    name: function (name) {                                                                                            // 129
      return _.contains(LISTS_METHODS, name);                                                                          // 130
    },                                                                                                                 // 131
    // Rate limit per connection ID                                                                                    // 133
    connectionId: function () {                                                                                        // 134
      return true;                                                                                                     // 134
    }                                                                                                                  // 134
  }, 5, 1000);                                                                                                         // 128
}                                                                                                                      // 136
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"todos":{"server":{"publications.js":["meteor/meteor","meteor/aldeed:simple-schema","../todos.js","../../lists/lists.js",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/todos/server/publications.js                                                                            //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var Meteor = void 0;                                                                                                   // 1
module.importSync("meteor/meteor", {                                                                                   // 1
  "Meteor": function (v) {                                                                                             // 1
    Meteor = v;                                                                                                        // 1
  }                                                                                                                    // 1
}, 0);                                                                                                                 // 1
var SimpleSchema = void 0;                                                                                             // 1
module.importSync("meteor/aldeed:simple-schema", {                                                                     // 1
  "SimpleSchema": function (v) {                                                                                       // 1
    SimpleSchema = v;                                                                                                  // 1
  }                                                                                                                    // 1
}, 1);                                                                                                                 // 1
var Todos = void 0;                                                                                                    // 1
module.importSync("../todos.js", {                                                                                     // 1
  "Todos": function (v) {                                                                                              // 1
    Todos = v;                                                                                                         // 1
  }                                                                                                                    // 1
}, 2);                                                                                                                 // 1
var Lists = void 0;                                                                                                    // 1
module.importSync("../../lists/lists.js", {                                                                            // 1
  "Lists": function (v) {                                                                                              // 1
    Lists = v;                                                                                                         // 1
  }                                                                                                                    // 1
}, 3);                                                                                                                 // 1
Meteor.publishComposite('todos.inList', function () {                                                                  // 9
  function todosInList(params) {                                                                                       // 9
    new SimpleSchema({                                                                                                 // 10
      listId: {                                                                                                        // 11
        type: String                                                                                                   // 11
      }                                                                                                                // 11
    }).validate(params);                                                                                               // 10
    var listId = params.listId;                                                                                        // 9
    var userId = this.userId;                                                                                          // 15
    return {                                                                                                           // 17
      find: function () {                                                                                              // 18
        var query = {                                                                                                  // 19
          _id: listId,                                                                                                 // 20
          $or: [{                                                                                                      // 21
            userId: {                                                                                                  // 21
              $exists: false                                                                                           // 21
            }                                                                                                          // 21
          }, {                                                                                                         // 21
            userId: userId                                                                                             // 21
          }]                                                                                                           // 21
        }; // We only need the _id field in this query, since it's only                                                // 19
        // used to drive the child queries to get the todos                                                            // 25
                                                                                                                       //
        var options = {                                                                                                // 26
          fields: {                                                                                                    // 27
            _id: 1                                                                                                     // 27
          }                                                                                                            // 27
        };                                                                                                             // 26
        return Lists.find(query, options);                                                                             // 30
      },                                                                                                               // 31
      children: [{                                                                                                     // 33
        find: function (list) {                                                                                        // 34
          return Todos.find({                                                                                          // 35
            listId: list._id                                                                                           // 35
          }, {                                                                                                         // 35
            fields: Todos.publicFields                                                                                 // 35
          });                                                                                                          // 35
        }                                                                                                              // 36
      }]                                                                                                               // 33
    };                                                                                                                 // 17
  }                                                                                                                    // 39
                                                                                                                       //
  return todosInList;                                                                                                  // 9
}());                                                                                                                  // 9
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"incompleteCountDenormalizer.js":["meteor/underscore","meteor/check","./todos.js","../lists/lists.js",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/todos/incompleteCountDenormalizer.js                                                                    //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var _ = void 0;                                                                                                        // 1
                                                                                                                       //
module.importSync("meteor/underscore", {                                                                               // 1
  "_": function (v) {                                                                                                  // 1
    _ = v;                                                                                                             // 1
  }                                                                                                                    // 1
}, 0);                                                                                                                 // 1
var check = void 0;                                                                                                    // 1
module.importSync("meteor/check", {                                                                                    // 1
  "check": function (v) {                                                                                              // 1
    check = v;                                                                                                         // 1
  }                                                                                                                    // 1
}, 1);                                                                                                                 // 1
var Todos = void 0;                                                                                                    // 1
module.importSync("./todos.js", {                                                                                      // 1
  "Todos": function (v) {                                                                                              // 1
    Todos = v;                                                                                                         // 1
  }                                                                                                                    // 1
}, 2);                                                                                                                 // 1
var Lists = void 0;                                                                                                    // 1
module.importSync("../lists/lists.js", {                                                                               // 1
  "Lists": function (v) {                                                                                              // 1
    Lists = v;                                                                                                         // 1
  }                                                                                                                    // 1
}, 3);                                                                                                                 // 1
var incompleteCountDenormalizer = {                                                                                    // 7
  _updateList: function (listId) {                                                                                     // 8
    // Recalculate the correct incomplete count direct from MongoDB                                                    // 9
    var incompleteCount = Todos.find({                                                                                 // 10
      listId: listId,                                                                                                  // 11
      checked: false                                                                                                   // 12
    }).count();                                                                                                        // 10
    Lists.update(listId, {                                                                                             // 15
      $set: {                                                                                                          // 15
        incompleteCount: incompleteCount                                                                               // 15
      }                                                                                                                // 15
    });                                                                                                                // 15
  },                                                                                                                   // 16
  afterInsertTodo: function (todo) {                                                                                   // 17
    this._updateList(todo.listId);                                                                                     // 18
  },                                                                                                                   // 19
  afterUpdateTodo: function (selector, modifier) {                                                                     // 20
    var _this = this;                                                                                                  // 20
                                                                                                                       //
    // We only support very limited operations on todos                                                                // 21
    check(modifier, {                                                                                                  // 22
      $set: Object                                                                                                     // 22
    }); // We can only deal with $set modifiers, but that's all we do in this app                                      // 22
                                                                                                                       //
    if (_.has(modifier.$set, 'checked')) {                                                                             // 25
      Todos.find(selector, {                                                                                           // 26
        fields: {                                                                                                      // 26
          listId: 1                                                                                                    // 26
        }                                                                                                              // 26
      }).forEach(function (todo) {                                                                                     // 26
        _this._updateList(todo.listId);                                                                                // 27
      });                                                                                                              // 28
    }                                                                                                                  // 29
  },                                                                                                                   // 30
  // Here we need to take the list of todos being removed, selected *before* the update                                // 31
  // because otherwise we can't figure out the relevant list id(s) (if the todo has been deleted)                      // 32
  afterRemoveTodos: function (todos) {                                                                                 // 33
    var _this2 = this;                                                                                                 // 33
                                                                                                                       //
    todos.forEach(function (todo) {                                                                                    // 34
      return _this2._updateList(todo.listId);                                                                          // 34
    });                                                                                                                // 34
  }                                                                                                                    // 35
};                                                                                                                     // 7
module.export("default", exports.default = incompleteCountDenormalizer);                                               // 1
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"methods.js":["meteor/meteor","meteor/underscore","meteor/mdg:validated-method","meteor/aldeed:simple-schema","meteor/ddp-rate-limiter","./todos.js","../lists/lists.js",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/todos/methods.js                                                                                        //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({                                                                                                        // 1
  insert: function () {                                                                                                // 1
    return insert;                                                                                                     // 1
  },                                                                                                                   // 1
  setCheckedStatus: function () {                                                                                      // 1
    return setCheckedStatus;                                                                                           // 1
  },                                                                                                                   // 1
  updateText: function () {                                                                                            // 1
    return updateText;                                                                                                 // 1
  },                                                                                                                   // 1
  remove: function () {                                                                                                // 1
    return remove;                                                                                                     // 1
  }                                                                                                                    // 1
});                                                                                                                    // 1
var Meteor = void 0;                                                                                                   // 1
module.importSync("meteor/meteor", {                                                                                   // 1
  "Meteor": function (v) {                                                                                             // 1
    Meteor = v;                                                                                                        // 1
  }                                                                                                                    // 1
}, 0);                                                                                                                 // 1
                                                                                                                       //
var _ = void 0;                                                                                                        // 1
                                                                                                                       //
module.importSync("meteor/underscore", {                                                                               // 1
  "_": function (v) {                                                                                                  // 1
    _ = v;                                                                                                             // 1
  }                                                                                                                    // 1
}, 1);                                                                                                                 // 1
var ValidatedMethod = void 0;                                                                                          // 1
module.importSync("meteor/mdg:validated-method", {                                                                     // 1
  "ValidatedMethod": function (v) {                                                                                    // 1
    ValidatedMethod = v;                                                                                               // 1
  }                                                                                                                    // 1
}, 2);                                                                                                                 // 1
var SimpleSchema = void 0;                                                                                             // 1
module.importSync("meteor/aldeed:simple-schema", {                                                                     // 1
  "SimpleSchema": function (v) {                                                                                       // 1
    SimpleSchema = v;                                                                                                  // 1
  }                                                                                                                    // 1
}, 3);                                                                                                                 // 1
var DDPRateLimiter = void 0;                                                                                           // 1
module.importSync("meteor/ddp-rate-limiter", {                                                                         // 1
  "DDPRateLimiter": function (v) {                                                                                     // 1
    DDPRateLimiter = v;                                                                                                // 1
  }                                                                                                                    // 1
}, 4);                                                                                                                 // 1
var Todos = void 0;                                                                                                    // 1
module.importSync("./todos.js", {                                                                                      // 1
  "Todos": function (v) {                                                                                              // 1
    Todos = v;                                                                                                         // 1
  }                                                                                                                    // 1
}, 5);                                                                                                                 // 1
var Lists = void 0;                                                                                                    // 1
module.importSync("../lists/lists.js", {                                                                               // 1
  "Lists": function (v) {                                                                                              // 1
    Lists = v;                                                                                                         // 1
  }                                                                                                                    // 1
}, 6);                                                                                                                 // 1
var insert = new ValidatedMethod({                                                                                     // 10
  name: 'todos.insert',                                                                                                // 11
  validate: Todos.simpleSchema().pick(['listId', 'text']).validator({                                                  // 12
    clean: true,                                                                                                       // 12
    filter: false                                                                                                      // 12
  }),                                                                                                                  // 12
  run: function (_ref) {                                                                                               // 13
    var listId = _ref.listId,                                                                                          // 13
        text = _ref.text;                                                                                              // 13
    var list = Lists.findOne(listId);                                                                                  // 14
                                                                                                                       //
    if (list.isPrivate() && list.userId !== this.userId) {                                                             // 16
      throw new Meteor.Error('todos.insert.accessDenied', 'Cannot add todos to a private list that is not yours');     // 17
    }                                                                                                                  // 19
                                                                                                                       //
    var todo = {                                                                                                       // 21
      listId: listId,                                                                                                  // 22
      text: text,                                                                                                      // 23
      checked: false,                                                                                                  // 24
      createdAt: new Date()                                                                                            // 25
    };                                                                                                                 // 21
    Todos.insert(todo);                                                                                                // 28
  }                                                                                                                    // 29
});                                                                                                                    // 10
var setCheckedStatus = new ValidatedMethod({                                                                           // 32
  name: 'todos.makeChecked',                                                                                           // 33
  validate: new SimpleSchema({                                                                                         // 34
    todoId: Todos.simpleSchema().schema('_id'),                                                                        // 35
    newCheckedStatus: Todos.simpleSchema().schema('checked')                                                           // 36
  }).validator({                                                                                                       // 34
    clean: true,                                                                                                       // 37
    filter: false                                                                                                      // 37
  }),                                                                                                                  // 37
  run: function (_ref2) {                                                                                              // 38
    var todoId = _ref2.todoId,                                                                                         // 38
        newCheckedStatus = _ref2.newCheckedStatus;                                                                     // 38
    var todo = Todos.findOne(todoId);                                                                                  // 39
                                                                                                                       //
    if (todo.checked === newCheckedStatus) {                                                                           // 41
      // The status is already what we want, let's not do any extra work                                               // 42
      return;                                                                                                          // 43
    }                                                                                                                  // 44
                                                                                                                       //
    if (!todo.editableBy(this.userId)) {                                                                               // 46
      throw new Meteor.Error('todos.setCheckedStatus.accessDenied', 'Cannot edit checked status in a private list that is not yours');
    }                                                                                                                  // 49
                                                                                                                       //
    Todos.update(todoId, {                                                                                             // 51
      $set: {                                                                                                          // 51
        checked: newCheckedStatus                                                                                      // 52
      }                                                                                                                // 51
    });                                                                                                                // 51
  }                                                                                                                    // 54
});                                                                                                                    // 32
var updateText = new ValidatedMethod({                                                                                 // 57
  name: 'todos.updateText',                                                                                            // 58
  validate: new SimpleSchema({                                                                                         // 59
    todoId: Todos.simpleSchema().schema('_id'),                                                                        // 60
    newText: Todos.simpleSchema().schema('text')                                                                       // 61
  }).validator({                                                                                                       // 59
    clean: true,                                                                                                       // 62
    filter: false                                                                                                      // 62
  }),                                                                                                                  // 62
  run: function (_ref3) {                                                                                              // 63
    var todoId = _ref3.todoId,                                                                                         // 63
        newText = _ref3.newText;                                                                                       // 63
    // This is complex auth stuff - perhaps denormalizing a userId onto todos                                          // 64
    // would be correct here?                                                                                          // 65
    var todo = Todos.findOne(todoId);                                                                                  // 66
                                                                                                                       //
    if (!todo.editableBy(this.userId)) {                                                                               // 68
      throw new Meteor.Error('todos.updateText.accessDenied', 'Cannot edit todos in a private list that is not yours');
    }                                                                                                                  // 71
                                                                                                                       //
    Todos.update(todoId, {                                                                                             // 73
      $set: {                                                                                                          // 74
        text: _.isUndefined(newText) ? null : newText                                                                  // 75
      }                                                                                                                // 74
    });                                                                                                                // 73
  }                                                                                                                    // 78
});                                                                                                                    // 57
var remove = new ValidatedMethod({                                                                                     // 81
  name: 'todos.remove',                                                                                                // 82
  validate: new SimpleSchema({                                                                                         // 83
    todoId: Todos.simpleSchema().schema('_id')                                                                         // 84
  }).validator({                                                                                                       // 83
    clean: true,                                                                                                       // 85
    filter: false                                                                                                      // 85
  }),                                                                                                                  // 85
  run: function (_ref4) {                                                                                              // 86
    var todoId = _ref4.todoId;                                                                                         // 86
    var todo = Todos.findOne(todoId);                                                                                  // 87
                                                                                                                       //
    if (!todo.editableBy(this.userId)) {                                                                               // 89
      throw new Meteor.Error('todos.remove.accessDenied', 'Cannot remove todos in a private list that is not yours');  // 90
    }                                                                                                                  // 92
                                                                                                                       //
    Todos.remove(todoId);                                                                                              // 94
  }                                                                                                                    // 95
});                                                                                                                    // 81
                                                                                                                       //
// Get list of all method names on Todos                                                                               // 98
var TODOS_METHODS = _.pluck([insert, setCheckedStatus, updateText, remove], 'name');                                   // 99
                                                                                                                       //
if (Meteor.isServer) {                                                                                                 // 106
  // Only allow 5 todos operations per connection per second                                                           // 107
  DDPRateLimiter.addRule({                                                                                             // 108
    name: function (name) {                                                                                            // 109
      return _.contains(TODOS_METHODS, name);                                                                          // 110
    },                                                                                                                 // 111
    // Rate limit per connection ID                                                                                    // 113
    connectionId: function () {                                                                                        // 114
      return true;                                                                                                     // 114
    }                                                                                                                  // 114
  }, 5, 1000);                                                                                                         // 108
}                                                                                                                      // 116
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"todos.js":["babel-runtime/helpers/classCallCheck","babel-runtime/helpers/possibleConstructorReturn","babel-runtime/helpers/inherits","meteor/mongo","meteor/dburles:factory","meteor/aldeed:simple-schema","faker","./incompleteCountDenormalizer.js","../lists/lists.js",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/todos/todos.js                                                                                          //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var _classCallCheck2 = require("babel-runtime/helpers/classCallCheck");                                                //
                                                                                                                       //
var _classCallCheck3 = _interopRequireDefault(_classCallCheck2);                                                       //
                                                                                                                       //
var _possibleConstructorReturn2 = require("babel-runtime/helpers/possibleConstructorReturn");                          //
                                                                                                                       //
var _possibleConstructorReturn3 = _interopRequireDefault(_possibleConstructorReturn2);                                 //
                                                                                                                       //
var _inherits2 = require("babel-runtime/helpers/inherits");                                                            //
                                                                                                                       //
var _inherits3 = _interopRequireDefault(_inherits2);                                                                   //
                                                                                                                       //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }                      //
                                                                                                                       //
module.export({                                                                                                        // 1
  Todos: function () {                                                                                                 // 1
    return Todos;                                                                                                      // 1
  }                                                                                                                    // 1
});                                                                                                                    // 1
var Mongo = void 0;                                                                                                    // 1
module.importSync("meteor/mongo", {                                                                                    // 1
  "Mongo": function (v) {                                                                                              // 1
    Mongo = v;                                                                                                         // 1
  }                                                                                                                    // 1
}, 0);                                                                                                                 // 1
var Factory = void 0;                                                                                                  // 1
module.importSync("meteor/dburles:factory", {                                                                          // 1
  "Factory": function (v) {                                                                                            // 1
    Factory = v;                                                                                                       // 1
  }                                                                                                                    // 1
}, 1);                                                                                                                 // 1
var SimpleSchema = void 0;                                                                                             // 1
module.importSync("meteor/aldeed:simple-schema", {                                                                     // 1
  "SimpleSchema": function (v) {                                                                                       // 1
    SimpleSchema = v;                                                                                                  // 1
  }                                                                                                                    // 1
}, 2);                                                                                                                 // 1
var faker = void 0;                                                                                                    // 1
module.importSync("faker", {                                                                                           // 1
  "default": function (v) {                                                                                            // 1
    faker = v;                                                                                                         // 1
  }                                                                                                                    // 1
}, 3);                                                                                                                 // 1
var incompleteCountDenormalizer = void 0;                                                                              // 1
module.importSync("./incompleteCountDenormalizer.js", {                                                                // 1
  "default": function (v) {                                                                                            // 1
    incompleteCountDenormalizer = v;                                                                                   // 1
  }                                                                                                                    // 1
}, 4);                                                                                                                 // 1
var Lists = void 0;                                                                                                    // 1
module.importSync("../lists/lists.js", {                                                                               // 1
  "Lists": function (v) {                                                                                              // 1
    Lists = v;                                                                                                         // 1
  }                                                                                                                    // 1
}, 5);                                                                                                                 // 1
                                                                                                                       //
var TodosCollection = function (_Mongo$Collection) {                                                                   //
  (0, _inherits3.default)(TodosCollection, _Mongo$Collection);                                                         //
                                                                                                                       //
  function TodosCollection() {                                                                                         //
    (0, _classCallCheck3.default)(this, TodosCollection);                                                              //
    return (0, _possibleConstructorReturn3.default)(this, _Mongo$Collection.apply(this, arguments));                   //
  }                                                                                                                    //
                                                                                                                       //
  TodosCollection.prototype.insert = function () {                                                                     //
    function insert(doc, callback) {                                                                                   //
      var ourDoc = doc;                                                                                                // 11
      ourDoc.createdAt = ourDoc.createdAt || new Date();                                                               // 12
                                                                                                                       //
      var result = _Mongo$Collection.prototype.insert.call(this, ourDoc, callback);                                    // 13
                                                                                                                       //
      incompleteCountDenormalizer.afterInsertTodo(ourDoc);                                                             // 14
      return result;                                                                                                   // 15
    }                                                                                                                  // 16
                                                                                                                       //
    return insert;                                                                                                     //
  }();                                                                                                                 //
                                                                                                                       //
  TodosCollection.prototype.update = function () {                                                                     //
    function update(selector, modifier) {                                                                              //
      var result = _Mongo$Collection.prototype.update.call(this, selector, modifier);                                  // 18
                                                                                                                       //
      incompleteCountDenormalizer.afterUpdateTodo(selector, modifier);                                                 // 19
      return result;                                                                                                   // 20
    }                                                                                                                  // 21
                                                                                                                       //
    return update;                                                                                                     //
  }();                                                                                                                 //
                                                                                                                       //
  TodosCollection.prototype.remove = function () {                                                                     //
    function remove(selector) {                                                                                        //
      var todos = this.find(selector).fetch();                                                                         // 23
                                                                                                                       //
      var result = _Mongo$Collection.prototype.remove.call(this, selector);                                            // 24
                                                                                                                       //
      incompleteCountDenormalizer.afterRemoveTodos(todos);                                                             // 25
      return result;                                                                                                   // 26
    }                                                                                                                  // 27
                                                                                                                       //
    return remove;                                                                                                     //
  }();                                                                                                                 //
                                                                                                                       //
  return TodosCollection;                                                                                              //
}(Mongo.Collection);                                                                                                   //
                                                                                                                       //
var Todos = new TodosCollection('todos');                                                                              // 30
// Deny all client-side updates since we will be using methods to manage this collection                               // 32
Todos.deny({                                                                                                           // 33
  insert: function () {                                                                                                // 34
    return true;                                                                                                       // 34
  },                                                                                                                   // 34
  update: function () {                                                                                                // 35
    return true;                                                                                                       // 35
  },                                                                                                                   // 35
  remove: function () {                                                                                                // 36
    return true;                                                                                                       // 36
  }                                                                                                                    // 36
});                                                                                                                    // 33
Todos.schema = new SimpleSchema({                                                                                      // 39
  _id: {                                                                                                               // 40
    type: String,                                                                                                      // 41
    regEx: SimpleSchema.RegEx.Id                                                                                       // 42
  },                                                                                                                   // 40
  listId: {                                                                                                            // 44
    type: String,                                                                                                      // 45
    regEx: SimpleSchema.RegEx.Id,                                                                                      // 46
    denyUpdate: true                                                                                                   // 47
  },                                                                                                                   // 44
  text: {                                                                                                              // 49
    type: String,                                                                                                      // 50
    max: 100,                                                                                                          // 51
    optional: true                                                                                                     // 52
  },                                                                                                                   // 49
  createdAt: {                                                                                                         // 54
    type: Date,                                                                                                        // 55
    denyUpdate: true                                                                                                   // 56
  },                                                                                                                   // 54
  checked: {                                                                                                           // 58
    type: Boolean,                                                                                                     // 59
    defaultValue: false                                                                                                // 60
  }                                                                                                                    // 58
});                                                                                                                    // 39
Todos.attachSchema(Todos.schema); // This represents the keys from Lists objects that should be published              // 64
// to the client. If we add secret properties to List objects, don't list                                              // 67
// them here to keep them private to the server.                                                                       // 68
                                                                                                                       //
Todos.publicFields = {                                                                                                 // 69
  listId: 1,                                                                                                           // 70
  text: 1,                                                                                                             // 71
  createdAt: 1,                                                                                                        // 72
  checked: 1                                                                                                           // 73
}; // TODO This factory has a name - do we have a code style for this?                                                 // 69
//   - usually I've used the singular, sometimes you have more than one though, like                                   // 77
//   'todo', 'emptyTodo', 'checkedTodo'                                                                                // 78
                                                                                                                       //
Factory.define('todo', Todos, {                                                                                        // 79
  listId: function () {                                                                                                // 80
    return Factory.get('list');                                                                                        // 80
  },                                                                                                                   // 80
  text: function () {                                                                                                  // 81
    return faker.lorem.sentence();                                                                                     // 81
  },                                                                                                                   // 81
  createdAt: function () {                                                                                             // 82
    return new Date();                                                                                                 // 82
  }                                                                                                                    // 82
});                                                                                                                    // 79
Todos.helpers({                                                                                                        // 85
  list: function () {                                                                                                  // 86
    return Lists.findOne(this.listId);                                                                                 // 87
  },                                                                                                                   // 88
  editableBy: function (userId) {                                                                                      // 89
    return this.list().editableBy(userId);                                                                             // 90
  }                                                                                                                    // 91
});                                                                                                                    // 85
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]}},"startup":{"both":{"index.js":["./useraccounts-configuration.js",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/startup/both/index.js                                                                                       //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.importSync("./useraccounts-configuration.js");                                                                  // 1
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"useraccounts-configuration.js":["meteor/useraccounts:core",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/startup/both/useraccounts-configuration.js                                                                  //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var AccountsTemplates = void 0;                                                                                        // 1
module.importSync("meteor/useraccounts:core", {                                                                        // 1
  "AccountsTemplates": function (v) {                                                                                  // 1
    AccountsTemplates = v;                                                                                             // 1
  }                                                                                                                    // 1
}, 0);                                                                                                                 // 1
/**                                                                                                                    // 3
 * The useraccounts package must be configured for both client and server to work properly.                            //
 * See the Guide for reference (https://github.com/meteor-useraccounts/core/blob/master/Guide.md)                      //
 */AccountsTemplates.configure({                                                                                       //
  showForgotPasswordLink: true,                                                                                        // 9
  defaultTemplate: 'Auth_page',                                                                                        // 10
  defaultLayout: 'App_body',                                                                                           // 11
  defaultContentRegion: 'main',                                                                                        // 12
  defaultLayoutRegions: {}                                                                                             // 13
});                                                                                                                    // 8
AccountsTemplates.configureRoute('signIn', {                                                                           // 16
  name: 'signin',                                                                                                      // 17
  path: '/signin'                                                                                                      // 18
});                                                                                                                    // 16
AccountsTemplates.configureRoute('signUp', {                                                                           // 21
  name: 'join',                                                                                                        // 22
  path: '/join'                                                                                                        // 23
});                                                                                                                    // 21
AccountsTemplates.configureRoute('forgotPwd');                                                                         // 26
AccountsTemplates.configureRoute('resetPwd', {                                                                         // 28
  name: 'resetPwd',                                                                                                    // 29
  path: '/reset-password'                                                                                              // 30
});                                                                                                                    // 28
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"server":{"fixtures.js":["meteor/meteor","../../api/lists/lists.js","../../api/todos/todos.js",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/startup/server/fixtures.js                                                                                  //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var Meteor = void 0;                                                                                                   // 1
module.importSync("meteor/meteor", {                                                                                   // 1
  "Meteor": function (v) {                                                                                             // 1
    Meteor = v;                                                                                                        // 1
  }                                                                                                                    // 1
}, 0);                                                                                                                 // 1
var Lists = void 0;                                                                                                    // 1
module.importSync("../../api/lists/lists.js", {                                                                        // 1
  "Lists": function (v) {                                                                                              // 1
    Lists = v;                                                                                                         // 1
  }                                                                                                                    // 1
}, 1);                                                                                                                 // 1
var Todos = void 0;                                                                                                    // 1
module.importSync("../../api/todos/todos.js", {                                                                        // 1
  "Todos": function (v) {                                                                                              // 1
    Todos = v;                                                                                                         // 1
  }                                                                                                                    // 1
}, 2);                                                                                                                 // 1
// if the database is empty on server start, create some sample data.                                                  // 5
Meteor.startup(function () {                                                                                           // 6
  if (Lists.find().count() === 0) {                                                                                    // 7
    var data = [{                                                                                                      // 8
      name: 'Meteor Principles',                                                                                       // 10
      items: ['Data on the Wire', 'One Language', 'Database Everywhere', 'Latency Compensation', 'Full Stack Reactivity', 'Embrace the Ecosystem', 'Simplicity Equals Productivity']
    }, {                                                                                                               // 9
      name: 'Languages',                                                                                               // 22
      items: ['Lisp', 'C', 'C++', 'Python', 'Ruby', 'JavaScript', 'Scala', 'Erlang', '6502 Assembly']                  // 23
    }, {                                                                                                               // 21
      name: 'Favorite Scientists',                                                                                     // 36
      items: ['Ada Lovelace', 'Grace Hopper', 'Marie Curie', 'Carl Friedrich Gauss', 'Nikola Tesla', 'Claude Shannon']
    }];                                                                                                                // 35
    var timestamp = new Date().getTime();                                                                              // 48
    data.forEach(function (list) {                                                                                     // 50
      var listId = Lists.insert({                                                                                      // 51
        name: list.name,                                                                                               // 52
        incompleteCount: list.items.length                                                                             // 53
      });                                                                                                              // 51
      list.items.forEach(function (text) {                                                                             // 56
        Todos.insert({                                                                                                 // 57
          listId: listId,                                                                                              // 58
          text: text,                                                                                                  // 59
          createdAt: new Date(timestamp)                                                                               // 60
        });                                                                                                            // 57
        timestamp += 1; // ensure unique timestamp.                                                                    // 63
      });                                                                                                              // 64
    });                                                                                                                // 65
  }                                                                                                                    // 66
});                                                                                                                    // 67
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"index.js":["./fixtures.js","./reset-password-email.js","./security.js","./register-api.js",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/startup/server/index.js                                                                                     //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.importSync("./fixtures.js");                                                                                    // 1
module.importSync("./reset-password-email.js");                                                                        // 1
module.importSync("./security.js");                                                                                    // 1
module.importSync("./register-api.js");                                                                                // 1
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"register-api.js":["../../api/lists/methods.js","../../api/lists/server/publications.js","../../api/todos/methods.js","../../api/todos/server/publications.js",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/startup/server/register-api.js                                                                              //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.importSync("../../api/lists/methods.js");                                                                       // 1
module.importSync("../../api/lists/server/publications.js");                                                           // 1
module.importSync("../../api/todos/methods.js");                                                                       // 1
module.importSync("../../api/todos/server/publications.js");                                                           // 1
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"reset-password-email.js":["meteor/accounts-base",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/startup/server/reset-password-email.js                                                                      //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var Accounts = void 0;                                                                                                 // 1
module.importSync("meteor/accounts-base", {                                                                            // 1
  "Accounts": function (v) {                                                                                           // 1
    Accounts = v;                                                                                                      // 1
  }                                                                                                                    // 1
}, 0);                                                                                                                 // 1
Accounts.emailTemplates.siteName = 'Meteor Guide Todos Example';                                                       // 4
Accounts.emailTemplates.from = 'Meteor Todos Accounts <accounts@example.com>';                                         // 5
Accounts.emailTemplates.resetPassword = {                                                                              // 7
  subject: function () {                                                                                               // 8
    return 'Reset your password on Meteor Todos';                                                                      // 9
  },                                                                                                                   // 10
  text: function (user, url) {                                                                                         // 11
    return "Hello!\n\nClick the link below to reset your password on Meteor Todos.\n\n" + url + "\n\nIf you didn't request this email, please ignore it.\n\nThanks,\nThe Meteor Todos team\n";
  }                                                                                                                    // 23
};                                                                                                                     // 7
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"security.js":["meteor/meteor","meteor/ddp-rate-limiter","meteor/underscore",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/startup/server/security.js                                                                                  //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var Meteor = void 0;                                                                                                   // 1
module.importSync("meteor/meteor", {                                                                                   // 1
  "Meteor": function (v) {                                                                                             // 1
    Meteor = v;                                                                                                        // 1
  }                                                                                                                    // 1
}, 0);                                                                                                                 // 1
var DDPRateLimiter = void 0;                                                                                           // 1
module.importSync("meteor/ddp-rate-limiter", {                                                                         // 1
  "DDPRateLimiter": function (v) {                                                                                     // 1
    DDPRateLimiter = v;                                                                                                // 1
  }                                                                                                                    // 1
}, 1);                                                                                                                 // 1
                                                                                                                       //
var _ = void 0;                                                                                                        // 1
                                                                                                                       //
module.importSync("meteor/underscore", {                                                                               // 1
  "_": function (v) {                                                                                                  // 1
    _ = v;                                                                                                             // 1
  }                                                                                                                    // 1
}, 2);                                                                                                                 // 1
// Don't let people write arbitrary data to their 'profile' field from the client                                      // 5
Meteor.users.deny({                                                                                                    // 6
  update: function () {                                                                                                // 7
    return true;                                                                                                       // 8
  }                                                                                                                    // 9
}); // Get a list of all accounts methods by running `Meteor.server.method_handlers` in meteor shell                   // 6
                                                                                                                       //
var AUTH_METHODS = ['login', 'logout', 'logoutOtherClients', 'getNewToken', 'removeOtherTokens', 'configureLoginService', 'changePassword', 'forgotPassword', 'resetPassword', 'verifyEmail', 'createUser', 'ATRemoveService', 'ATCreateUserServer', 'ATResendVerificationEmail']; // Only allow 2 login attempts per connection per 5 seconds
                                                                                                                       //
DDPRateLimiter.addRule({                                                                                               // 31
  name: function (name) {                                                                                              // 32
    return _.contains(AUTH_METHODS, name);                                                                             // 33
  },                                                                                                                   // 34
  // Rate limit per connection ID                                                                                      // 36
  connectionId: function () {                                                                                          // 37
    return true;                                                                                                       // 37
  }                                                                                                                    // 37
}, 2, 5000);                                                                                                           // 31
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]}}},"i18n":{"en.i18n.json":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// i18n/en.i18n.json                                                                                                   //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var _ = Package.underscore._,
    package_name = "project",
    namespace = "project";

if (package_name != "project") {
    namespace = TAPi18n.packages[package_name].namespace;
}
TAPi18n._enable({"helper_name":"_","supported_languages":null,"i18n_files_route":"/tap-i18n","preloaded_langs":[],"cdn_path":null});
TAPi18n.languages_names["en"] = ["English","English"];
// integrate the fallback language translations 
translations = {};
translations[namespace] = {"lists":{"makePrivate":{"notLoggedIn":"Must be logged in to make private lists.","lastPublicList":"Cannot make the last public list private."},"makePublic":{"notLoggedIn":"Must be logged in.","accessDenied":"You don't have permission to edit this list."},"updateName":{"accessDenied":"You don't have permission to edit this list."},"remove":{"accessDenied":"'You don't have permission to remove this list.'","lastPublicList":"Cannot delete the last public list.","confirm":"Are you sure you want to delete the list"},"show":{"cancel":"Cancel","showMenu":"Show Menu","selectAction":"Select an action","makePublic":"Make Public","makePrivate":"Make Private","delete":"Delete","makeListPublic":"Make list public","makeListPrivate":"Make list private","deleteList":"Delete list","typeToAdd":"Type to add new tasks","noTasks":"No tasks here","addAbove":"Add new tasks using the field above","loading":"Loading tasks..."},"insert":{"list":"List"}},"todos":{"insert":{"accessDenied":"Cannot add todos to a private list that is not yours"},"setCheckedStatus":{"accessDenied":"Cannot edit todos in a private list that is not yours"},"updateText":{"accessDenied":"Cannot edit todos in a private list that is not yours"},"remove":{"accessDenied":"Cannot remove todos in a private list that is not yours"},"item":{"taskName":"Task name"}},"useraccounts":{"atTitle":{"subtitle":"Signing in allows you to have private lists"}},"layouts":{"appBody":{"logout":"Logout","login":"Sign In","join":"Join","newList":"New List","newListError":"Could not create list.","tryingToConnect":"Trying to connect","connectionIssue":"There seems to be a connection issue"}},"pages":{"appNotFound":{"pageNotFound":"Page not found"}}};
TAPi18n._loadLangFileObject("en", translations);
TAPi18n._registerServerTranslator("en", namespace);

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"fr.i18n.json":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// i18n/fr.i18n.json                                                                                                   //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var _ = Package.underscore._,
    package_name = "project",
    namespace = "project";

if (package_name != "project") {
    namespace = TAPi18n.packages[package_name].namespace;
}
TAPi18n.languages_names["fr"] = ["French (France)","Français"];
if(_.isUndefined(TAPi18n.translations["fr"])) {
  TAPi18n.translations["fr"] = {};
}

if(_.isUndefined(TAPi18n.translations["fr"][namespace])) {
  TAPi18n.translations["fr"][namespace] = {};
}

_.extend(TAPi18n.translations["fr"][namespace], {"lists":{"makePrivate":{"notLoggedIn":"Doit être connecté pour réaliser des listes privées.","lastPublicList":"Vous ne pouvez pas faire la dernière liste publique privée."},"makePublic":{"notLoggedIn":"Doit être connecté.","accessDenied":"Vous n'êtes pas autorisé à modifier cette liste."},"updateName":{"accessDenied":"Vous n'êtes pas autorisé à modifier cette liste."},"remove":{"accessDenied":"'Vous n'êtes pas autorisé à supprimer cette liste.'","lastPublicList":"Vous ne pouvez pas supprimer la dernière liste publique.","confirm":"Etes-vous sûr de vouloir supprimer la liste"},"show":{"cancel":"Annuler","showMenu":"Afficher le menu","selectAction":"Sélectionnez une action","makePublic":"Rendre publique","makePrivate":"Rendre privé","delete":"Effacer","makeListPublic":"Ouvrir la liste pour le public","makeListPrivate":"Fermer la liste au public","deleteList":"Effacer la liste","typeToAdd":"Tapez pour ajouter de nouvelles tâches","noTasks":"Aucune tâche ici","addAbove":"Ajouter de nouvelles tâches ci-dessus","loading":"Chargement sauvé tâches..."},"insert":{"list":"Liste"}},"todos":{"insert":{"accessDenied":"Vous ne pouvez pas ajouter todo à une liste privée qui ne vous appartient pas"},"setCheckedStatus":{"accessDenied":"Vous ne pouvez pas modifier todos dans une liste privée qui ne vous appartient pas"},"updateText":{"accessDenied":"Vous ne pouvez pas modifier todos dans une liste privée qui ne vous appartient pas"},"remove":{"accessDenied":"Vous ne pouvez pas supprimer todos dans une liste privée qui ne vous appartient pas"},"item":{"taskName":"Nom de la tâche"}},"useraccounts":{"atTitle":{"subtitle":"Connexion à vous permet d'avoir des listes privées"}},"layouts":{"appBody":{"logout":"Se déconnecter","login":"Se connecter","join":"Joindre","newList":"Nouvelle liste","newListError":"La liste ne peut être créé.","tryingToConnect":"Tentative de connexion","connectionIssue":"Il semble y avoir un problème de connexion"}},"pages":{"appNotFound":{"pageNotFound":"Page non trouvée"}}});
TAPi18n._registerServerTranslator("fr", namespace);

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"server":{"main.js":["/imports/startup/server","/imports/startup/both",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/main.js                                                                                                      //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.importSync("/imports/startup/server");                                                                          // 1
module.importSync("/imports/startup/both");                                                                            // 1
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]}},{"extensions":[".js",".json"]});
require("./i18n/en.i18n.json");
require("./i18n/fr.i18n.json");
require("./server/main.js");
//# sourceMappingURL=app.js.map
